Including this readMe.txt file the zip file 
contains 2 files:

1) QSEALC-NordeaDevPortal.cer, and
2) QSEALC-NordeaDevPortal.p12

The p12 file includes the private key and 
pin for using it is 1111

The certificate is of type eIDAS QSEALC and can be used for testing connection
towards Nordea Developer Portal. 
It is used for testing the HTTP signature, not for identification of a party. 
ClientID & Secret are required.

The connection should be succesful with this certifiate but rejected if another certificate is used for signing. 

Note the expiration date of the certificate 
(Expires Jan 10 2021 serial nr 31de220289f15a3b00ef3fcaa4027739)

Please note also:
This test certificate is issued by Bundesdruckerei GmbH. For inquiries please contact PSD2@bdr.de.

By downloading and using it you accept to use these only for Nordea Development Portal and within EU/EEA only.


Nordea Bank Abp